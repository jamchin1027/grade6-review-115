複習小島｜六上期末冒險 Windows APP

使用方式：解壓縮整個 ZIP 資料夾，雙擊「Grade6Review.exe」。不要只搬動 EXE，旁邊的 DLL 和 AppContent 資料夾也是 APP 的一部分。

這是 Windows 桌面程式，不會開啟一般瀏覽器或網址列。內容完整內建，可離線使用。進度保存在目前 Windows 使用者的本機 APP 資料，不會上傳。

需要 Microsoft Edge WebView2 Runtime。Windows 11 通常已包含；若 APP 提示缺少，請先安裝 Microsoft 官方 WebView2 Runtime，再開啟 APP。

若要備份或轉移進度，請在 APP 的「學習紀錄備份」匯出 JSON，並在另一台電腦匯入。
